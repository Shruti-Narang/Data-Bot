"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Book, Code, Zap, Webhook, HelpCircle, Rocket } from "lucide-react"

const navigation = [
  {
    title: "Getting Started",
    items: [
      { title: "Introduction", href: "/docs/getting-started", icon: Rocket },
      { title: "Quick Start", href: "/docs/quick-start", icon: Zap },
    ],
  },
  {
    title: "API",
    items: [
      { title: "API Reference", href: "/docs/api-reference", icon: Book },
      { title: "Authentication", href: "/docs/authentication", icon: Code },
      { title: "Rate Limits", href: "/docs/rate-limits", icon: Code },
    ],
  },
  {
    title: "Features",
    items: [
      { title: "Schema Guide", href: "/docs/schemas", icon: Code },
      { title: "Webhooks", href: "/docs/webhooks", icon: Webhook },
      { title: "Exports", href: "/docs/exports", icon: Code },
    ],
  },
  {
    title: "SDKs",
    items: [
      { title: "JavaScript/Node.js", href: "/docs/sdks", icon: Code },
      { title: "Python", href: "/docs/sdks#python", icon: Code },
      { title: "PHP", href: "/docs/sdks#php", icon: Code },
      { title: "Ruby", href: "/docs/sdks#ruby", icon: Code },
    ],
  },
  {
    title: "Help",
    items: [
      { title: "FAQ", href: "/docs/faq", icon: HelpCircle },
      { title: "Support", href: "/docs/support", icon: HelpCircle },
    ],
  },
]

export function DocsNavigation() {
  const pathname = usePathname()

  return (
    <div className="hidden lg:block w-64 border-r border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900">
      <ScrollArea className="h-[calc(100vh-4rem)] py-6 px-4">
        <nav className="space-y-6">
          {navigation.map((section) => (
            <div key={section.title}>
              <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-3">{section.title}</h4>
              <ul className="space-y-1">
                {section.items.map((item) => {
                  const isActive = pathname === item.href
                  return (
                    <li key={item.href}>
                      <Link
                        href={item.href}
                        className={cn(
                          "flex items-center px-3 py-2 text-sm rounded-md transition-colors",
                          isActive
                            ? "bg-blue-50 dark:bg-blue-950/20 text-blue-700 dark:text-blue-300"
                            : "text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800",
                        )}
                      >
                        <item.icon className="mr-3 h-4 w-4" />
                        {item.title}
                      </Link>
                    </li>
                  )
                })}
              </ul>
            </div>
          ))}
        </nav>
      </ScrollArea>
    </div>
  )
}
