"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ModeToggle } from "@/components/mode-toggle"
import { Search, Menu } from "lucide-react"
import { useState } from "react"

export function DocsHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-950/80 backdrop-blur-sm">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">PF</span>
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Parse Forge
              </span>
            </Link>
            <div className="hidden sm:block">
              <span className="text-sm text-muted-foreground">Documentation</span>
            </div>
          </div>

          {/* Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            <Link href="/docs/getting-started" className="text-sm hover:text-blue-600 transition-colors">
              Getting Started
            </Link>
            <Link href="/docs/api-reference" className="text-sm hover:text-blue-600 transition-colors">
              API Reference
            </Link>
            <Link href="/docs/schemas" className="text-sm hover:text-blue-600 transition-colors">
              Schemas
            </Link>
            <Link href="/docs/sdks" className="text-sm hover:text-blue-600 transition-colors">
              SDKs
            </Link>
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="hidden sm:flex">
              <Search className="h-4 w-4 mr-2" />
              Search
            </Button>
            <ModeToggle />
            <Button asChild size="sm">
              <Link href="/dashboard">Dashboard</Link>
            </Button>
            <Button variant="ghost" size="sm" className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              <Menu className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-slate-200 dark:border-slate-800 py-4">
            <div className="flex flex-col space-y-3">
              <Link href="/docs/getting-started" className="text-sm hover:text-blue-600 transition-colors">
                Getting Started
              </Link>
              <Link href="/docs/api-reference" className="text-sm hover:text-blue-600 transition-colors">
                API Reference
              </Link>
              <Link href="/docs/schemas" className="text-sm hover:text-blue-600 transition-colors">
                Schemas
              </Link>
              <Link href="/docs/sdks" className="text-sm hover:text-blue-600 transition-colors">
                SDKs
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
