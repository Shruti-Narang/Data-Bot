"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Trash2, Edit, AlertCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface WebhooksManagerProps {
  userId: string
}

export function WebhooksManager({ userId }: WebhooksManagerProps) {
  const [webhooks, setWebhooks] = useState([])
  const [loading, setLoading] = useState(true)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [editingWebhook, setEditingWebhook] = useState<any>(null)
  const [formData, setFormData] = useState({
    name: "",
    url: "",
    events: [] as string[],
    secret: "",
  })
  const { toast } = useToast()

  const availableEvents = [
    { id: "job.completed", label: "Job Completed", description: "Triggered when a parsing job completes successfully" },
    { id: "job.failed", label: "Job Failed", description: "Triggered when a parsing job fails" },
    { id: "job.started", label: "Job Started", description: "Triggered when a parsing job begins processing" },
  ]

  useEffect(() => {
    fetchWebhooks()
  }, [])

  const fetchWebhooks = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/webhooks")
      const data = await response.json()
      if (response.ok) {
        setWebhooks(data.webhooks || [])
      } else {
        throw new Error(data.error)
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch webhooks",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async () => {
    if (!formData.name || !formData.url || formData.events.length === 0) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    try {
      const url = editingWebhook ? `/api/webhooks/${editingWebhook.id}` : "/api/webhooks"
      const method = editingWebhook ? "PUT" : "POST"

      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      const data = await response.json()

      if (response.ok) {
        toast({
          title: "Success",
          description: `Webhook ${editingWebhook ? "updated" : "created"} successfully`,
        })
        setIsCreateDialogOpen(false)
        setEditingWebhook(null)
        setFormData({ name: "", url: "", events: [], secret: "" })
        fetchWebhooks()
      } else {
        throw new Error(data.error)
      }
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to ${editingWebhook ? "update" : "create"} webhook`,
        variant: "destructive",
      })
    }
  }

  const handleDelete = async (webhookId: string) => {
    try {
      const response = await fetch(`/api/webhooks/${webhookId}`, {
        method: "DELETE",
      })

      if (response.ok) {
        toast({
          title: "Success",
          description: "Webhook deleted successfully",
        })
        fetchWebhooks()
      } else {
        throw new Error("Failed to delete webhook")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete webhook",
        variant: "destructive",
      })
    }
  }

  const handleEdit = (webhook: any) => {
    setEditingWebhook(webhook)
    setFormData({
      name: webhook.name,
      url: webhook.url,
      events: webhook.events,
      secret: webhook.secret || "",
    })
    setIsCreateDialogOpen(true)
  }

  const handleEventChange = (eventId: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      events: checked ? [...prev.events, eventId] : prev.events.filter((e) => e !== eventId),
    }))
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Webhooks</CardTitle>
              <CardDescription>Receive real-time notifications when events occur</CardDescription>
            </div>
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Create Webhook
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>{editingWebhook ? "Edit Webhook" : "Create Webhook"}</DialogTitle>
                  <DialogDescription>
                    Configure a webhook to receive notifications when parsing events occur
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Name</Label>
                      <Input
                        id="name"
                        placeholder="My Webhook"
                        value={formData.name}
                        onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="url">Webhook URL</Label>
                      <Input
                        id="url"
                        placeholder="https://your-app.com/webhook"
                        value={formData.url}
                        onChange={(e) => setFormData((prev) => ({ ...prev, url: e.target.value }))}
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Events</Label>
                    <div className="space-y-3 mt-2">
                      {availableEvents.map((event) => (
                        <div key={event.id} className="flex items-start space-x-3">
                          <Checkbox
                            id={event.id}
                            checked={formData.events.includes(event.id)}
                            onCheckedChange={(checked) => handleEventChange(event.id, checked as boolean)}
                          />
                          <div className="space-y-1">
                            <Label htmlFor={event.id} className="text-sm font-medium">
                              {event.label}
                            </Label>
                            <p className="text-xs text-muted-foreground">{event.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="secret">Secret (Optional)</Label>
                    <Input
                      id="secret"
                      placeholder="webhook_secret_key"
                      value={formData.secret}
                      onChange={(e) => setFormData((prev) => ({ ...prev, secret: e.target.value }))}
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Used to verify webhook authenticity via HMAC signature
                    </p>
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setIsCreateDialogOpen(false)
                      setEditingWebhook(null)
                      setFormData({ name: "", url: "", events: [], secret: "" })
                    }}
                  >
                    Cancel
                  </Button>
                  <Button onClick={handleSubmit}>{editingWebhook ? "Update" : "Create"} Webhook</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>URL</TableHead>
                  <TableHead>Events</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Triggered</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  [...Array(3)].map((_, i) => (
                    <TableRow key={i}>
                      <TableCell>
                        <div className="animate-pulse h-4 bg-slate-200 dark:bg-slate-700 rounded w-32"></div>
                      </TableCell>
                      <TableCell>
                        <div className="animate-pulse h-4 bg-slate-200 dark:bg-slate-700 rounded w-48"></div>
                      </TableCell>
                      <TableCell>
                        <div className="animate-pulse h-4 bg-slate-200 dark:bg-slate-700 rounded w-24"></div>
                      </TableCell>
                      <TableCell>
                        <div className="animate-pulse h-6 bg-slate-200 dark:bg-slate-700 rounded w-16"></div>
                      </TableCell>
                      <TableCell>
                        <div className="animate-pulse h-4 bg-slate-200 dark:bg-slate-700 rounded w-24"></div>
                      </TableCell>
                      <TableCell>
                        <div className="animate-pulse h-8 bg-slate-200 dark:bg-slate-700 rounded w-16 ml-auto"></div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : webhooks.length > 0 ? (
                  webhooks.map((webhook: any) => (
                    <TableRow key={webhook.id}>
                      <TableCell className="font-medium">{webhook.name}</TableCell>
                      <TableCell>
                        <code className="text-xs bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded">
                          {webhook.url.length > 40 ? `${webhook.url.substring(0, 40)}...` : webhook.url}
                        </code>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {webhook.events.slice(0, 2).map((event: string) => (
                            <Badge key={event} variant="secondary" className="text-xs">
                              {event.split(".")[1]}
                            </Badge>
                          ))}
                          {webhook.events.length > 2 && (
                            <Badge variant="outline" className="text-xs">
                              +{webhook.events.length - 2}
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Badge variant={webhook.is_active ? "default" : "secondary"}>
                            {webhook.is_active ? "Active" : "Inactive"}
                          </Badge>
                          {webhook.failure_count > 0 && (
                            <div className="flex items-center text-amber-600">
                              <AlertCircle className="h-4 w-4" />
                              <span className="text-xs ml-1">{webhook.failure_count}</span>
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        {webhook.last_triggered_at ? new Date(webhook.last_triggered_at).toLocaleDateString() : "Never"}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <Button variant="ghost" size="sm" onClick={() => handleEdit(webhook)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(webhook.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      <div className="text-slate-500 dark:text-slate-400">
                        <p className="font-medium">No webhooks configured</p>
                        <p className="text-sm">Create your first webhook to receive real-time notifications</p>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
