"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { WebhooksManager } from "./webhooks-manager"
import { ExternalIntegrations } from "./external-integrations"
import { Webhook, Zap, Download } from "lucide-react"

interface IntegrationsManagerProps {
  userId: string
}

export function IntegrationsManager({ userId }: IntegrationsManagerProps) {
  return (
    <div className="space-y-6">
      <Tabs defaultValue="webhooks" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="webhooks" className="flex items-center space-x-2">
            <Webhook className="h-4 w-4" />
            <span>Webhooks</span>
          </TabsTrigger>
          <TabsTrigger value="external" className="flex items-center space-x-2">
            <Zap className="h-4 w-4" />
            <span>External Services</span>
          </TabsTrigger>
          <TabsTrigger value="exports" className="flex items-center space-x-2">
            <Download className="h-4 w-4" />
            <span>Export Formats</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="webhooks">
          <WebhooksManager userId={userId} />
        </TabsContent>

        <TabsContent value="external">
          <ExternalIntegrations userId={userId} />
        </TabsContent>

        <TabsContent value="exports">
          <ExportFormats />
        </TabsContent>
      </Tabs>
    </div>
  )
}

function ExportFormats() {
  const formats = [
    {
      name: "JSON",
      description: "Standard JSON format for easy integration",
      icon: "📄",
      supported: true,
    },
    {
      name: "CSV",
      description: "Comma-separated values for spreadsheet applications",
      icon: "📊",
      supported: true,
    },
    {
      name: "Excel (XLSX)",
      description: "Microsoft Excel format with multiple sheets",
      icon: "📈",
      supported: true,
    },
    {
      name: "XML",
      description: "Structured XML format for enterprise systems",
      icon: "🏷️",
      supported: true,
    },
    {
      name: "Google Sheets",
      description: "Direct export to Google Sheets",
      icon: "📋",
      supported: false,
    },
    {
      name: "Airtable",
      description: "Export to Airtable bases",
      icon: "🗃️",
      supported: false,
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {formats.map((format) => (
        <Card key={format.name} className={!format.supported ? "opacity-60" : ""}>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span className="text-2xl">{format.icon}</span>
              <span>{format.name}</span>
              {format.supported ? (
                <Badge variant="default">Available</Badge>
              ) : (
                <Badge variant="secondary">Coming Soon</Badge>
              )}
            </CardTitle>
            <CardDescription>{format.description}</CardDescription>
          </CardHeader>
          <CardContent>
            {format.supported ? (
              <p className="text-sm text-muted-foreground">
                Available in the playground and via API. Export your parsed data instantly.
              </p>
            ) : (
              <p className="text-sm text-muted-foreground">This format will be available in a future update.</p>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
