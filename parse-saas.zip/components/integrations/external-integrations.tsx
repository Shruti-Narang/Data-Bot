"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ExternalLink } from "lucide-react"

interface ExternalIntegrationsProps {
  userId: string
}

export function ExternalIntegrations({ userId }: ExternalIntegrationsProps) {
  const integrations = [
    {
      name: "Zapier",
      description: "Connect Parse Forge to 5000+ apps with automated workflows",
      icon: "⚡",
      status: "available",
      setupUrl: "https://zapier.com/apps/parse-forge",
    },
    {
      name: "Google Sheets",
      description: "Automatically send parsed data to Google Sheets",
      icon: "📊",
      status: "coming_soon",
      setupUrl: null,
    },
    {
      name: "Slack",
      description: "Get notifications and parsed data in your Slack channels",
      icon: "💬",
      status: "coming_soon",
      setupUrl: null,
    },
    {
      name: "Discord",
      description: "Receive parsing notifications in Discord servers",
      icon: "🎮",
      status: "coming_soon",
      setupUrl: null,
    },
    {
      name: "Airtable",
      description: "Send structured data directly to Airtable bases",
      icon: "🗃️",
      status: "coming_soon",
      setupUrl: null,
    },
    {
      name: "Make (Integromat)",
      description: "Build complex automation scenarios with Make",
      icon: "🔧",
      status: "coming_soon",
      setupUrl: null,
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {integrations.map((integration) => (
        <Card key={integration.name} className={integration.status !== "available" ? "opacity-60" : ""}>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span className="text-2xl">{integration.icon}</span>
                <span>{integration.name}</span>
              </div>
              {integration.status === "available" ? (
                <Badge variant="default">Available</Badge>
              ) : (
                <Badge variant="secondary">Coming Soon</Badge>
              )}
            </CardTitle>
            <CardDescription>{integration.description}</CardDescription>
          </CardHeader>
          <CardContent>
            {integration.status === "available" ? (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Ready to use! Click the button below to set up your integration.
                </p>
                <Button className="w-full" asChild>
                  <a href={integration.setupUrl!} target="_blank" rel="noopener noreferrer">
                    Set Up Integration
                    <ExternalLink className="h-4 w-4 ml-2" />
                  </a>
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  This integration is in development and will be available soon.
                </p>
                <Button variant="outline" className="w-full bg-transparent" disabled>
                  Coming Soon
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
