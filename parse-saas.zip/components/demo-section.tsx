"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Upload, Sparkles } from "lucide-react"

export function DemoSection() {
  const [inputText, setInputText] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [results, setResults] = useState<any>(null)

  const handleDemo = async () => {
    if (!inputText.trim()) return

    setIsProcessing(true)
    // Simulate AI processing
    setTimeout(() => {
      setResults({
        entities: [
          { type: "Person", value: "John Smith", confidence: 0.95 },
          { type: "Date", value: "2024-01-15", confidence: 0.92 },
          { type: "Amount", value: "$1,250.00", confidence: 0.98 },
        ],
        summary: "Invoice document containing payment information for consulting services.",
        structured_data: {
          invoice_number: "INV-2024-001",
          due_date: "2024-02-15",
          total_amount: 1250.0,
          currency: "USD",
        },
      })
      setIsProcessing(false)
    }, 2000)
  }

  return (
    <section id="demo" className="py-20 md:py-32">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="font-poppins font-bold text-3xl md:text-5xl mb-4">Try It Live</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Paste any text or document content below to see our AI parsing in action
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Input Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="h-5 w-5" />
                  Input Document
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  placeholder="Paste your document text here... For example: 'Invoice #INV-2024-001 from John Smith dated January 15, 2024 for consulting services totaling $1,250.00 due February 15, 2024.'"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  className="min-h-[200px] resize-none"
                />
                <Button onClick={handleDemo} disabled={!inputText.trim() || isProcessing} className="w-full">
                  {isProcessing ? (
                    <>
                      <Sparkles className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 h-4 w-4" />
                      Parse with AI
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Results Section */}
            <Card>
              <CardHeader>
                <CardTitle>Parsed Results</CardTitle>
              </CardHeader>
              <CardContent>
                {results ? (
                  <div className="space-y-6">
                    <div>
                      <h4 className="font-semibold mb-3">Extracted Entities</h4>
                      <div className="space-y-2">
                        {results.entities.map((entity: any, index: number) => (
                          <div key={index} className="flex items-center justify-between p-2 bg-muted rounded-lg">
                            <div>
                              <Badge variant="secondary" className="mr-2">
                                {entity.type}
                              </Badge>
                              <span className="font-medium">{entity.value}</span>
                            </div>
                            <span className="text-sm text-muted-foreground">
                              {Math.round(entity.confidence * 100)}%
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-3">Structured Data</h4>
                      <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto">
                        {JSON.stringify(results.structured_data, null, 2)}
                      </pre>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <Sparkles className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Parsed results will appear here</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
