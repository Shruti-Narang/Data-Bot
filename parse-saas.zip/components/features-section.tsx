import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText, Zap, Code, Shield, Globe, BarChart3 } from "lucide-react"

const features = [
  {
    icon: FileText,
    title: "Document Parsing",
    description: "Support for PDF, DOCX, TXT, and more. Extract text, tables, and metadata with precision.",
  },
  {
    icon: Zap,
    title: "Real-time Processing",
    description: "Get results instantly with our optimized AI models. No waiting, no delays.",
  },
  {
    icon: Code,
    title: "No-code Setup",
    description: "Simple drag-and-drop interface. No technical knowledge required to get started.",
  },
  {
    icon: Shield,
    title: "Enterprise Security",
    description: "Bank-level encryption and compliance with SOC2, GDPR, and HIPAA standards.",
  },
  {
    icon: Globe,
    title: "API Integrations",
    description: "Connect with Slack, Zapier, Google Sheets, and 100+ other tools seamlessly.",
  },
  {
    icon: BarChart3,
    title: "Analytics Dashboard",
    description: "Track parsing accuracy, usage metrics, and performance insights in real-time.",
  },
]

export function FeaturesSection() {
  return (
    <section id="features" className="py-20 md:py-32">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="font-poppins font-bold text-3xl md:text-5xl mb-4">Powerful Features for Every Need</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Everything you need to transform unstructured documents into actionable data
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="group hover:shadow-lg transition-all duration-300 border-border/50 bg-card/50 backdrop-blur-sm"
            >
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <feature.icon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="font-poppins font-semibold">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base leading-relaxed">{feature.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
