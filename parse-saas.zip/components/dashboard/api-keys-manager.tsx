"use client"

import { useEffect, useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Copy, Eye, EyeOff, Key, Plus, Trash2 } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"

interface ApiKeysManagerProps {
  userId: string
}

export function ApiKeysManager({ userId }: ApiKeysManagerProps) {
  const [apiKeys, setApiKeys] = useState([])
  const [loading, setLoading] = useState(true)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [newKeyName, setNewKeyName] = useState("")
  const [createdKey, setCreatedKey] = useState<string | null>(null)
  const [visibleKeys, setVisibleKeys] = useState<Set<string>>(new Set())
  const { toast } = useToast()

  useEffect(() => {
    fetchApiKeys()
  }, [])

  const fetchApiKeys = async () => {
    const supabase = createClient()
    setLoading(true)

    try {
      const { data, error } = await supabase
        .from("api_keys")
        .select("*")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })

      if (error) throw error
      setApiKeys(data || [])
    } catch (error) {
      console.error("Failed to fetch API keys:", error)
      toast({
        title: "Error",
        description: "Failed to fetch API keys",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const createApiKey = async () => {
    if (!newKeyName.trim()) return

    const supabase = createClient()

    try {
      // Generate a random API key
      const keyValue = `pf_${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`
      const keyPrefix = keyValue.substring(0, 8) + "..."

      const { error } = await supabase.from("api_keys").insert({
        user_id: userId,
        name: newKeyName,
        key_hash: keyValue, // In production, this should be hashed
        key_prefix: keyPrefix,
      })

      if (error) throw error

      setCreatedKey(keyValue)
      setNewKeyName("")
      fetchApiKeys()

      toast({
        title: "Success",
        description: "API key created successfully",
      })
    } catch (error) {
      console.error("Failed to create API key:", error)
      toast({
        title: "Error",
        description: "Failed to create API key",
        variant: "destructive",
      })
    }
  }

  const deleteApiKey = async (keyId: string) => {
    const supabase = createClient()

    try {
      const { error } = await supabase.from("api_keys").delete().eq("id", keyId)

      if (error) throw error

      fetchApiKeys()
      toast({
        title: "Success",
        description: "API key deleted successfully",
      })
    } catch (error) {
      console.error("Failed to delete API key:", error)
      toast({
        title: "Error",
        description: "Failed to delete API key",
        variant: "destructive",
      })
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied",
      description: "API key copied to clipboard",
    })
  }

  const toggleKeyVisibility = (keyId: string) => {
    const newVisibleKeys = new Set(visibleKeys)
    if (newVisibleKeys.has(keyId)) {
      newVisibleKeys.delete(keyId)
    } else {
      newVisibleKeys.add(keyId)
    }
    setVisibleKeys(newVisibleKeys)
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>API Keys</CardTitle>
            <CardDescription>Manage your API keys for programmatic access</CardDescription>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Create Key
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create API Key</DialogTitle>
                <DialogDescription>Create a new API key for programmatic access to Parse Forge</DialogDescription>
              </DialogHeader>
              {createdKey ? (
                <div className="space-y-4">
                  <div className="p-4 bg-green-50 dark:bg-green-950/20 rounded-lg">
                    <p className="text-sm text-green-800 dark:text-green-200 mb-2">
                      Your API key has been created. Copy it now - you won't be able to see it again.
                    </p>
                    <div className="flex items-center space-x-2">
                      <code className="flex-1 p-2 bg-white dark:bg-slate-800 rounded border text-sm font-mono">
                        {createdKey}
                      </code>
                      <Button size="sm" onClick={() => copyToClipboard(createdKey)}>
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="keyName">Key Name</Label>
                    <Input
                      id="keyName"
                      placeholder="e.g., Production API, Development"
                      value={newKeyName}
                      onChange={(e) => setNewKeyName(e.target.value)}
                    />
                  </div>
                </div>
              )}
              <DialogFooter>
                {createdKey ? (
                  <Button
                    onClick={() => {
                      setCreatedKey(null)
                      setIsCreateDialogOpen(false)
                    }}
                  >
                    Done
                  </Button>
                ) : (
                  <>
                    <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={createApiKey} disabled={!newKeyName.trim()}>
                      Create Key
                    </Button>
                  </>
                )}
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Key</TableHead>
                <TableHead>Created</TableHead>
                <TableHead>Last Used</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                [...Array(3)].map((_, i) => (
                  <TableRow key={i}>
                    <TableCell>
                      <div className="animate-pulse h-4 bg-slate-200 dark:bg-slate-700 rounded w-32"></div>
                    </TableCell>
                    <TableCell>
                      <div className="animate-pulse h-4 bg-slate-200 dark:bg-slate-700 rounded w-48"></div>
                    </TableCell>
                    <TableCell>
                      <div className="animate-pulse h-4 bg-slate-200 dark:bg-slate-700 rounded w-24"></div>
                    </TableCell>
                    <TableCell>
                      <div className="animate-pulse h-4 bg-slate-200 dark:bg-slate-700 rounded w-24"></div>
                    </TableCell>
                    <TableCell>
                      <div className="animate-pulse h-6 bg-slate-200 dark:bg-slate-700 rounded w-16"></div>
                    </TableCell>
                    <TableCell>
                      <div className="animate-pulse h-8 bg-slate-200 dark:bg-slate-700 rounded w-16 ml-auto"></div>
                    </TableCell>
                  </TableRow>
                ))
              ) : apiKeys.length > 0 ? (
                apiKeys.map((key: any) => (
                  <TableRow key={key.id}>
                    <TableCell className="font-medium">{key.name}</TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono">
                          {visibleKeys.has(key.id) ? key.key_hash : key.key_prefix}
                        </code>
                        <Button variant="ghost" size="sm" onClick={() => toggleKeyVisibility(key.id)}>
                          {visibleKeys.has(key.id) ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                        {visibleKeys.has(key.id) && (
                          <Button variant="ghost" size="sm" onClick={() => copyToClipboard(key.key_hash)}>
                            <Copy className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{new Date(key.created_at).toLocaleDateString()}</TableCell>
                    <TableCell>
                      {key.last_used_at ? new Date(key.last_used_at).toLocaleDateString() : "Never"}
                    </TableCell>
                    <TableCell>
                      <Badge variant={key.is_active ? "default" : "secondary"}>
                        {key.is_active ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteApiKey(key.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8">
                    <div className="flex flex-col items-center space-y-4">
                      <Key className="h-12 w-12 text-slate-400" />
                      <div className="text-slate-500 dark:text-slate-400">
                        <p className="font-medium">No API keys yet</p>
                        <p className="text-sm">Create your first API key to get started</p>
                      </div>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
