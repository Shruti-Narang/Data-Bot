"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Activity, Clock, Key, Zap } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import Link from "next/link"

interface DashboardOverviewProps {
  user: any
  profile: any
}

export function DashboardOverview({ user, profile }: DashboardOverviewProps) {
  const [stats, setStats] = useState({
    totalJobs: 0,
    completedJobs: 0,
    failedJobs: 0,
    pendingJobs: 0,
    apiKeys: 0,
  })
  const [recentJobs, setRecentJobs] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    const supabase = createClient()

    try {
      // Fetch job statistics
      const { data: jobs } = await supabase.from("parse_jobs").select("status").eq("user_id", user.id)

      const jobStats = {
        totalJobs: jobs?.length || 0,
        completedJobs: jobs?.filter((job) => job.status === "completed").length || 0,
        failedJobs: jobs?.filter((job) => job.status === "failed").length || 0,
        pendingJobs: jobs?.filter((job) => job.status === "pending" || job.status === "processing").length || 0,
      }

      // Fetch API keys count
      const { data: apiKeys } = await supabase
        .from("api_keys")
        .select("id")
        .eq("user_id", user.id)
        .eq("is_active", true)

      // Fetch recent jobs
      const { data: recent } = await supabase
        .from("parse_jobs")
        .select("id, url, status, created_at")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(5)

      setStats({
        ...jobStats,
        apiKeys: apiKeys?.length || 0,
      })
      setRecentJobs(recent || [])
    } catch (error) {
      console.error("Failed to fetch dashboard data:", error)
    } finally {
      setLoading(false)
    }
  }

  const successRate = stats.totalJobs > 0 ? (stats.completedJobs / stats.totalJobs) * 100 : 0

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100">
          Welcome back, {profile?.full_name || user.email}
        </h1>
        <p className="text-slate-600 dark:text-slate-400 mt-2">Here's what's happening with your Parse Forge account</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Jobs</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalJobs}</div>
            <p className="text-xs text-muted-foreground">All time parsing jobs</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{successRate.toFixed(1)}%</div>
            <Progress value={successRate} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Jobs</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pendingJobs}</div>
            <p className="text-xs text-muted-foreground">Currently processing</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">API Keys</CardTitle>
            <Key className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.apiKeys}</div>
            <p className="text-xs text-muted-foreground">Active keys</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Jobs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Recent Jobs</CardTitle>
            <CardDescription>Your latest parsing jobs</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-slate-200 dark:bg-slate-700 rounded w-1/2"></div>
                  </div>
                ))}
              </div>
            ) : recentJobs.length > 0 ? (
              <div className="space-y-4">
                {recentJobs.map((job: any) => (
                  <div key={job.id} className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">{job.url}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {new Date(job.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <Badge
                      variant={
                        job.status === "completed" ? "default" : job.status === "failed" ? "destructive" : "secondary"
                      }
                    >
                      {job.status}
                    </Badge>
                  </div>
                ))}
                <Button asChild variant="outline" className="w-full bg-transparent">
                  <Link href="/dashboard/jobs">View All Jobs</Link>
                </Button>
              </div>
            ) : (
              <div className="text-center py-6">
                <p className="text-slate-500 dark:text-slate-400 mb-4">No jobs yet</p>
                <Button asChild>
                  <Link href="/dashboard/playground">Start Parsing</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Get started with Parse Forge</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button asChild className="w-full">
              <Link href="/dashboard/playground">Try the Playground</Link>
            </Button>
            <Button asChild variant="outline" className="w-full bg-transparent">
              <Link href="/dashboard/api-keys">Create API Key</Link>
            </Button>
            <Button asChild variant="outline" className="w-full bg-transparent">
              <Link href="/docs">View Documentation</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
