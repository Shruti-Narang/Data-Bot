import { Card, CardContent } from "@/components/ui/card"

const integrations = [
  {
    name: "Slack",
    logo: "/slack-logo.png",
    description: "Send parsed results directly to Slack channels",
  },
  {
    name: "Zapier",
    logo: "/zapier-logo.png",
    description: "Connect with 5000+ apps via Zapier",
  },
  {
    name: "Google Sheets",
    logo: "/google-sheets-logo.png",
    description: "Export data directly to Google Sheets",
  },
  {
    name: "Microsoft Excel",
    logo: "/placeholder-06svw.png",
    description: "Generate Excel files automatically",
  },
  {
    name: "Salesforce",
    logo: "/salesforce-logo.png",
    description: "Sync parsed data with Salesforce CRM",
  },
  {
    name: "API Access",
    logo: "/api-integration-icon.png",
    description: "Full REST API for custom integrations",
  },
]

export function IntegrationsSection() {
  return (
    <section className="py-20 md:py-32 bg-muted/30">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="font-poppins font-bold text-3xl md:text-5xl mb-4">Seamless Integrations</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Connect Parse Forge with your favorite tools and workflows
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 max-w-5xl mx-auto">
          {integrations.map((integration, index) => (
            <Card
              key={index}
              className="group hover:shadow-lg transition-all duration-300 bg-card/50 backdrop-blur-sm border-border/50"
            >
              <CardContent className="p-6 text-center">
                <div className="mb-4 group-hover:scale-110 transition-transform duration-300">
                  <img
                    src={integration.logo || "/placeholder.svg"}
                    alt={integration.name}
                    className="h-10 w-auto mx-auto"
                  />
                </div>
                <h3 className="font-semibold text-sm mb-2">{integration.name}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">{integration.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
