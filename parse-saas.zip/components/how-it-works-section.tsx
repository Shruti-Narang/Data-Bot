import { Card, CardContent } from "@/components/ui/card"
import { Upload, Brain, Download } from "lucide-react"

const steps = [
  {
    icon: Upload,
    title: "Upload Documents",
    description: "Drag and drop your files or paste text directly into our secure platform.",
  },
  {
    icon: Brain,
    title: "AI Processing",
    description: "Our advanced AI models analyze and extract structured data from your documents.",
  },
  {
    icon: Download,
    title: "Get Results",
    description: "Download parsed data in JSON, CSV, or Excel format, or send directly to your tools.",
  },
]

export function HowItWorksSection() {
  return (
    <section id="how-it-works" className="py-20 md:py-32 bg-muted/30">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="font-poppins font-bold text-3xl md:text-5xl mb-4">How It Works</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Three simple steps to transform your documents into structured data
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <Card className="text-center p-8 bg-card/50 backdrop-blur-sm border-border/50">
                <CardContent className="pt-6">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center mx-auto mb-6">
                    <step.icon className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <h3 className="font-poppins font-semibold text-xl mb-4">{step.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{step.description}</p>
                </CardContent>
              </Card>

              {/* Arrow connector */}
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                  <div className="w-8 h-0.5 bg-gradient-to-r from-primary to-secondary"></div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
