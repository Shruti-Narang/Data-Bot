"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Trash2, Wand2 } from "lucide-react"

interface SchemaBuilderProps {
  schema: any
  onSchemaChange: (schema: any) => void
}

export function SchemaBuilder({ schema, onSchemaChange }: SchemaBuilderProps) {
  const [customSchema, setCustomSchema] = useState("")

  const presetSchemas = {
    article: {
      title: "h1, .article-title, .post-title",
      author: ".author, .byline, .writer",
      content: ".content, .article-content, .post-content",
      publishDate: ".date, .publish-date, time",
      tags: ".tags, .tag",
    },
    product: {
      name: "h1, .product-title, .product-name",
      price: ".price, .cost, .product-price",
      description: ".description, .product-description",
      rating: ".rating, .stars",
      availability: ".availability, .stock",
    },
    listing: {
      items: ".item, .listing, .result",
      titles: ".item h2, .item h3",
      prices: ".item .price",
      links: ".item a",
    },
    contact: {
      name: "h1, .company-name",
      address: ".address, .location",
      phone: ".phone, .tel",
      email: ".email",
      hours: ".hours, .business-hours",
    },
  }

  const handlePresetSelect = (presetName: string) => {
    const preset = presetSchemas[presetName as keyof typeof presetSchemas]
    onSchemaChange(preset)
    setCustomSchema(JSON.stringify(preset, null, 2))
  }

  const handleCustomSchemaChange = (value: string) => {
    setCustomSchema(value)
    try {
      const parsed = JSON.parse(value)
      onSchemaChange(parsed)
    } catch {
      // Invalid JSON, don't update schema
    }
  }

  const clearSchema = () => {
    onSchemaChange(null)
    setCustomSchema("")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center">
          <Wand2 className="h-5 w-5 mr-2" />
          Schema Builder
        </CardTitle>
        <CardDescription>Define what data to extract from the website</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="presets" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="presets">Presets</TabsTrigger>
            <TabsTrigger value="custom">Custom</TabsTrigger>
          </TabsList>

          <TabsContent value="presets" className="space-y-4">
            <div className="space-y-3">
              <Label>Choose a preset schema</Label>
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(presetSchemas).map(([name, _]) => (
                  <Button
                    key={name}
                    variant="outline"
                    className="justify-start bg-transparent"
                    onClick={() => handlePresetSelect(name)}
                  >
                    {name.charAt(0).toUpperCase() + name.slice(1)}
                  </Button>
                ))}
              </div>
            </div>

            {schema && (
              <div className="space-y-2">
                <Label>Current Schema</Label>
                <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-md">
                  <pre className="text-xs overflow-x-auto">{JSON.stringify(schema, null, 2)}</pre>
                </div>
                <Button variant="outline" size="sm" onClick={clearSchema}>
                  <Trash2 className="h-4 w-4 mr-2" />
                  Clear Schema
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="custom" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="customSchema">Custom Schema (JSON)</Label>
              <Textarea
                id="customSchema"
                placeholder={`{
  "title": "h1",
  "content": ".content p",
  "links": "a[href]"
}`}
                value={customSchema}
                onChange={(e) => handleCustomSchemaChange(e.target.value)}
                className="font-mono text-sm"
                rows={8}
              />
              <p className="text-xs text-muted-foreground">
                Use CSS selectors to define what data to extract. Leave empty for auto-detection.
              </p>
            </div>

            {schema && (
              <div className="space-y-2">
                <Label>Schema Preview</Label>
                <div className="flex flex-wrap gap-1">
                  {Object.keys(schema).map((key) => (
                    <Badge key={key} variant="secondary">
                      {key}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
