"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Copy } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface CodeGeneratorProps {
  url: string
  schema?: any
  jobId?: string | null
}

export function CodeGenerator({ url, schema, jobId }: CodeGeneratorProps) {
  const { toast } = useToast()

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied",
      description: "Code copied to clipboard",
    })
  }

  const generateCode = (language: string): string => {
    const schemaStr = schema ? JSON.stringify(schema, null, 2) : "null"

    switch (language) {
      case "javascript":
        return `// Parse Forge - JavaScript Example
const response = await fetch('https://api.parseforge.com/parse', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    url: '${url}',
    schema: ${schemaStr},
    options: {
      includeImages: true,
      includeLinks: true
    }
  })
});

const data = await response.json();
console.log(data);`

      case "python":
        return `# Parse Forge - Python Example
import requests
import json

url = "https://api.parseforge.com/parse"
headers = {
    "Authorization": "Bearer YOUR_API_KEY",
    "Content-Type": "application/json"
}

payload = {
    "url": "${url}",
    "schema": ${schemaStr},
    "options": {
        "includeImages": True,
        "includeLinks": True
    }
}

response = requests.post(url, headers=headers, json=payload)
data = response.json()
print(json.dumps(data, indent=2))`

      case "curl":
        return `# Parse Forge - cURL Example
curl -X POST https://api.parseforge.com/parse \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "url": "${url}",
    "schema": ${schemaStr},
    "options": {
      "includeImages": true,
      "includeLinks": true
    }
  }'`

      case "php":
        return `<?php
// Parse Forge - PHP Example
$url = 'https://api.parseforge.com/parse';
$headers = [
    'Authorization: Bearer YOUR_API_KEY',
    'Content-Type: application/json'
];

$payload = [
    'url' => '${url}',
    'schema' => ${schemaStr},
    'options' => [
        'includeImages' => true,
        'includeLinks' => true
    ]
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);
print_r($data);
?>`

      default:
        return "// Select a language to see the code example"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Code Examples</CardTitle>
        <CardDescription>Use these examples to integrate Parse Forge into your application</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="javascript" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="javascript">JavaScript</TabsTrigger>
            <TabsTrigger value="python">Python</TabsTrigger>
            <TabsTrigger value="curl">cURL</TabsTrigger>
            <TabsTrigger value="php">PHP</TabsTrigger>
          </TabsList>

          {["javascript", "python", "curl", "php"].map((lang) => (
            <TabsContent key={lang} value={lang} className="space-y-4">
              <div className="relative">
                <pre className="bg-slate-900 text-slate-100 p-4 rounded-lg overflow-x-auto text-sm">
                  <code>{generateCode(lang)}</code>
                </pre>
                <Button
                  variant="outline"
                  size="sm"
                  className="absolute top-2 right-2 bg-transparent"
                  onClick={() => copyToClipboard(generateCode(lang))}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </TabsContent>
          ))}
        </Tabs>

        <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
          <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">Getting Started</h4>
          <ol className="text-sm text-blue-800 dark:text-blue-200 space-y-1 list-decimal list-inside">
            <li>Create an API key in your dashboard</li>
            <li>Replace YOUR_API_KEY with your actual API key</li>
            <li>Customize the URL and schema as needed</li>
            <li>Run the code in your application</li>
          </ol>
        </div>
      </CardContent>
    </Card>
  )
}
