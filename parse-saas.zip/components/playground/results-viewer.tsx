"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown, ChevronRight, Copy } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import type { JSX } from "react/jsx-runtime"

interface ResultsViewerProps {
  data: any
}

export function ResultsViewer({ data }: ResultsViewerProps) {
  const { toast } = useToast()

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied",
      description: "Content copied to clipboard",
    })
  }

  const renderValue = (value: any, key?: string): JSX.Element => {
    if (value === null || value === undefined) {
      return <span className="text-muted-foreground italic">null</span>
    }

    if (typeof value === "string") {
      return (
        <div className="group relative">
          <span className="text-sm">{value}</span>
          <Button
            variant="ghost"
            size="sm"
            className="opacity-0 group-hover:opacity-100 absolute -right-2 -top-1 h-6 w-6 p-0"
            onClick={() => copyToClipboard(value)}
          >
            <Copy className="h-3 w-3" />
          </Button>
        </div>
      )
    }

    if (typeof value === "number" || typeof value === "boolean") {
      return <Badge variant="outline">{String(value)}</Badge>
    }

    if (Array.isArray(value)) {
      return <ArrayViewer items={value} />
    }

    if (typeof value === "object") {
      return <ObjectViewer obj={value} />
    }

    return <span>{String(value)}</span>
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Extracted Data</CardTitle>
        <CardDescription>Structured data extracted from the website</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {Object.entries(data).map(([key, value]) => (
            <div key={key} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium text-sm uppercase tracking-wide text-muted-foreground">{key}</h4>
                <Badge variant="secondary">{Array.isArray(value) ? `${value.length} items` : typeof value}</Badge>
              </div>
              {renderValue(value, key)}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

function ArrayViewer({ items }: { items: any[] }) {
  const [isOpen, setIsOpen] = useState(false)

  if (items.length === 0) {
    return <span className="text-muted-foreground italic">Empty array</span>
  }

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <CollapsibleTrigger asChild>
        <Button variant="ghost" className="p-0 h-auto font-normal justify-start">
          {isOpen ? <ChevronDown className="h-4 w-4 mr-1" /> : <ChevronRight className="h-4 w-4 mr-1" />}
          <span className="text-sm">{items.length} items</span>
        </Button>
      </CollapsibleTrigger>
      <CollapsibleContent className="mt-2 space-y-2">
        {items.slice(0, 10).map((item, index) => (
          <div key={index} className="pl-4 border-l-2 border-slate-200 dark:border-slate-700">
            <div className="text-xs text-muted-foreground mb-1">Item {index + 1}</div>
            {typeof item === "string" ? (
              <div className="text-sm bg-slate-50 dark:bg-slate-800 p-2 rounded">{item}</div>
            ) : (
              <div className="text-sm">{JSON.stringify(item, null, 2)}</div>
            )}
          </div>
        ))}
        {items.length > 10 && (
          <div className="text-xs text-muted-foreground pl-4">... and {items.length - 10} more items</div>
        )}
      </CollapsibleContent>
    </Collapsible>
  )
}

function ObjectViewer({ obj }: { obj: any }) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <CollapsibleTrigger asChild>
        <Button variant="ghost" className="p-0 h-auto font-normal justify-start">
          {isOpen ? <ChevronDown className="h-4 w-4 mr-1" /> : <ChevronRight className="h-4 w-4 mr-1" />}
          <span className="text-sm">{Object.keys(obj).length} properties</span>
        </Button>
      </CollapsibleTrigger>
      <CollapsibleContent className="mt-2">
        <div className="pl-4 border-l-2 border-slate-200 dark:border-slate-700">
          <pre className="text-xs bg-slate-50 dark:bg-slate-800 p-2 rounded overflow-x-auto">
            {JSON.stringify(obj, null, 2)}
          </pre>
        </div>
      </CollapsibleContent>
    </Collapsible>
  )
}
