"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Play, Download, Loader2, AlertCircle, CheckCircle } from "lucide-react"
import { SchemaBuilder } from "./schema-builder"
import { ResultsViewer } from "./results-viewer"
import { CodeGenerator } from "./code-generator"
import { useToast } from "@/hooks/use-toast"

interface PlaygroundProps {
  userId: string
}

export function Playground({ userId }: PlaygroundProps) {
  const [url, setUrl] = useState("")
  const [schema, setSchema] = useState<any>(null)
  const [results, setResults] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [jobId, setJobId] = useState<string | null>(null)
  const { toast } = useToast()

  const handleParse = async () => {
    if (!url.trim()) {
      toast({
        title: "Error",
        description: "Please enter a URL to parse",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    setError(null)
    setResults(null)

    try {
      const response = await fetch("/api/parse", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          url: url.trim(),
          schema,
          options: {
            includeImages: true,
            includeLinks: true,
          },
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to parse website")
      }

      setResults(data.data)
      setJobId(data.job_id)
      toast({
        title: "Success",
        description: "Website parsed successfully!",
      })
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "An error occurred"
      setError(errorMessage)
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleExport = (format: string) => {
    if (!results) return

    let content: string
    let filename: string
    let mimeType: string

    switch (format) {
      case "json":
        content = JSON.stringify(results, null, 2)
        filename = "parse-results.json"
        mimeType = "application/json"
        break
      case "csv":
        // Simple CSV export for flat data
        content = convertToCSV(results.content)
        filename = "parse-results.csv"
        mimeType = "text/csv"
        break
      default:
        return
    }

    const blob = new Blob([content], { type: mimeType })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "Exported",
      description: `Results exported as ${format.toUpperCase()}`,
    })
  }

  const convertToCSV = (data: any): string => {
    if (!data || typeof data !== "object") return ""

    const rows: string[] = []
    const headers = new Set<string>()

    // Collect all possible headers
    const collectHeaders = (obj: any, prefix = "") => {
      for (const [key, value] of Object.entries(obj)) {
        const fullKey = prefix ? `${prefix}.${key}` : key
        if (Array.isArray(value)) {
          headers.add(fullKey)
        } else if (typeof value === "object" && value !== null) {
          collectHeaders(value, fullKey)
        } else {
          headers.add(fullKey)
        }
      }
    }

    collectHeaders(data)
    const headerArray = Array.from(headers)
    rows.push(headerArray.join(","))

    // Add data row
    const getValue = (obj: any, path: string): string => {
      const keys = path.split(".")
      let current = obj
      for (const key of keys) {
        if (current && typeof current === "object" && key in current) {
          current = current[key]
        } else {
          return ""
        }
      }
      if (Array.isArray(current)) {
        return current.join("; ")
      }
      return String(current || "")
    }

    const row = headerArray.map((header) => `"${getValue(data, header).replace(/"/g, '""')}"`).join(",")
    rows.push(row)

    return rows.join("\n")
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Playground</h1>
            <p className="text-slate-600 dark:text-slate-400 mt-1">Test and experiment with Parse Forge</p>
          </div>
          <div className="flex items-center space-x-2">
            {results && (
              <>
                <Button variant="outline" onClick={() => handleExport("json")} size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  JSON
                </Button>
                <Button variant="outline" onClick={() => handleExport("csv")} size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  CSV
                </Button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-2 h-full">
          {/* Left Panel - Input */}
          <div className="border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
            <ScrollArea className="h-full">
              <div className="p-6 space-y-6">
                {/* URL Input */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Target URL</CardTitle>
                    <CardDescription>Enter the website URL you want to parse</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="url">Website URL</Label>
                      <div className="flex space-x-2">
                        <Input
                          id="url"
                          placeholder="https://example.com"
                          value={url}
                          onChange={(e) => setUrl(e.target.value)}
                          onKeyDown={(e) => e.key === "Enter" && handleParse()}
                        />
                        <Button onClick={handleParse} disabled={loading || !url.trim()}>
                          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>

                    {/* Quick Examples */}
                    <div className="space-y-2">
                      <Label>Quick Examples</Label>
                      <div className="flex flex-wrap gap-2">
                        {[
                          "https://news.ycombinator.com",
                          "https://github.com/trending",
                          "https://www.producthunt.com",
                        ].map((example) => (
                          <Badge
                            key={example}
                            variant="outline"
                            className="cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800"
                            onClick={() => setUrl(example)}
                          >
                            {example.replace("https://", "")}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Schema Builder */}
                <SchemaBuilder schema={schema} onSchemaChange={setSchema} />

                {/* Status */}
                {(loading || error || results) && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Status</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {loading && (
                        <div className="flex items-center space-x-2 text-blue-600">
                          <Loader2 className="h-4 w-4 animate-spin" />
                          <span>Parsing website...</span>
                        </div>
                      )}
                      {error && (
                        <div className="flex items-center space-x-2 text-red-600">
                          <AlertCircle className="h-4 w-4" />
                          <span>{error}</span>
                        </div>
                      )}
                      {results && !loading && (
                        <div className="flex items-center space-x-2 text-green-600">
                          <CheckCircle className="h-4 w-4" />
                          <span>Parsing completed successfully</span>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </div>
            </ScrollArea>
          </div>

          {/* Right Panel - Results */}
          <div className="bg-slate-50 dark:bg-slate-950">
            <ScrollArea className="h-full">
              <div className="p-6">
                {results ? (
                  <Tabs defaultValue="results" className="space-y-4">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="results">Results</TabsTrigger>
                      <TabsTrigger value="metadata">Metadata</TabsTrigger>
                      <TabsTrigger value="code">Code</TabsTrigger>
                    </TabsList>

                    <TabsContent value="results" className="space-y-4">
                      <ResultsViewer data={results.content} />
                    </TabsContent>

                    <TabsContent value="metadata" className="space-y-4">
                      <Card>
                        <CardHeader>
                          <CardTitle>Parsing Metadata</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <Label className="text-muted-foreground">URL</Label>
                              <p className="font-mono text-xs break-all">{results.url}</p>
                            </div>
                            <div>
                              <Label className="text-muted-foreground">Title</Label>
                              <p>{results.title}</p>
                            </div>
                            <div>
                              <Label className="text-muted-foreground">Word Count</Label>
                              <p>{results.metadata.wordCount.toLocaleString()}</p>
                            </div>
                            <div>
                              <Label className="text-muted-foreground">Images</Label>
                              <p>{results.metadata.imageCount}</p>
                            </div>
                            <div>
                              <Label className="text-muted-foreground">Links</Label>
                              <p>{results.metadata.linkCount}</p>
                            </div>
                            <div>
                              <Label className="text-muted-foreground">Parsed At</Label>
                              <p>{new Date(results.metadata.timestamp).toLocaleString()}</p>
                            </div>
                          </div>
                          {results.description && (
                            <div>
                              <Label className="text-muted-foreground">Description</Label>
                              <p className="text-sm mt-1">{results.description}</p>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    </TabsContent>

                    <TabsContent value="code" className="space-y-4">
                      <CodeGenerator url={url} schema={schema} jobId={jobId} />
                    </TabsContent>
                  </Tabs>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-center space-y-4">
                    <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                      <Play className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100">Ready to Parse</h3>
                      <p className="text-slate-600 dark:text-slate-400 mt-1">
                        Enter a URL and click the play button to see Parse Forge in action
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>
          </div>
        </div>
      </div>
    </div>
  )
}
