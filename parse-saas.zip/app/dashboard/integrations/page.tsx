import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { DashboardSidebar } from "@/components/dashboard/dashboard-sidebar"
import { IntegrationsManager } from "@/components/integrations/integrations-manager"

export default async function IntegrationsPage() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()

  if (error || !user) {
    redirect("/auth/login")
  }

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-950">
      <DashboardSidebar />
      <main className="flex-1 overflow-y-auto">
        <div className="p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100">Integrations</h1>
            <p className="text-slate-600 dark:text-slate-400 mt-2">Connect Parse Forge with your favorite tools</p>
          </div>
          <IntegrationsManager userId={user.id} />
        </div>
      </main>
    </div>
  )
}
