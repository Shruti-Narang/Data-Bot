import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { DashboardSidebar } from "@/components/dashboard/dashboard-sidebar"
import { ApiKeysManager } from "@/components/dashboard/api-keys-manager"

export default async function ApiKeysPage() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()

  if (error || !user) {
    redirect("/auth/login")
  }

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-950">
      <DashboardSidebar />
      <main className="flex-1 overflow-y-auto">
        <div className="p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100">API Keys</h1>
            <p className="text-slate-600 dark:text-slate-400 mt-2">Manage your API keys for programmatic access</p>
          </div>
          <ApiKeysManager userId={user.id} />
        </div>
      </main>
    </div>
  )
}
