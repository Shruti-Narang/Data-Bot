import type React from "react"
import { DocsNavigation } from "@/components/docs/docs-navigation"
import { DocsHeader } from "@/components/docs/docs-header"

export default function DocsLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-white dark:bg-slate-950">
      <DocsHeader />
      <div className="flex">
        <DocsNavigation />
        <main className="flex-1 min-w-0">{children}</main>
      </div>
    </div>
  )
}
