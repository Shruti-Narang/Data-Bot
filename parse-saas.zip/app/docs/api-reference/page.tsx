import { DocsContent } from "@/components/docs/docs-content"

export default function ApiReferencePage() {
  const content = `
# API Reference

Parse Forge provides a simple REST API for extracting structured data from websites.

## Base URL

\`\`\`
https://api.parseforge.com
\`\`\`

## Authentication

All API requests require authentication using your API key in the Authorization header:

\`\`\`
Authorization: Bearer YOUR_API_KEY
\`\`\`

## Endpoints

### Parse Website

Extract structured data from a website.

\`\`\`http
POST /parse
\`\`\`

#### Request Body

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| \`url\` | string | Yes | The URL to parse |
| \`schema\` | object | No | Custom extraction schema |
| \`options\` | object | No | Parsing options |

#### Options

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| \`includeImages\` | boolean | false | Include image data in results |
| \`includeLinks\` | boolean | false | Include link data in results |
| \`maxDepth\` | number | 1 | Maximum crawl depth |
| \`followPagination\` | boolean | false | Follow pagination links |

#### Example Request

\`\`\`bash
curl -X POST https://api.parseforge.com/parse \\
  -H "Authorization: Bearer pf_abc123..." \\
  -H "Content-Type: application/json" \\
  -d '{
    "url": "https://example.com/blog",
    "schema": {
      "title": "h1",
      "author": ".author",
      "content": ".post-content p",
      "tags": ".tag"
    },
    "options": {
      "includeImages": true,
      "includeLinks": true
    }
  }'
\`\`\`

#### Response

\`\`\`json
{
  "success": true,
  "job_id": "job_abc123",
  "data": {
    "url": "https://example.com/blog",
    "title": "Example Blog Post",
    "description": "This is an example blog post...",
    "content": {
      "title": "How to Build APIs",
      "author": "John Doe",
      "content": [
        "Building APIs is an essential skill...",
        "In this post, we'll cover..."
      ],
      "tags": ["api", "development", "tutorial"]
    },
    "metadata": {
      "timestamp": "2024-01-15T10:30:00Z",
      "contentType": "text/html",
      "wordCount": 1250,
      "imageCount": 3,
      "linkCount": 15
    }
  }
}
\`\`\`

### Get Job Status

Check the status of a parsing job.

\`\`\`http
GET /parse/{job_id}
\`\`\`

#### Response

\`\`\`json
{
  "id": "job_abc123",
  "url": "https://example.com",
  "status": "completed",
  "result": { ... },
  "created_at": "2024-01-15T10:30:00Z",
  "completed_at": "2024-01-15T10:30:05Z"
}
\`\`\`

### List Jobs

Get a list of your parsing jobs.

\`\`\`http
GET /jobs?limit=50&offset=0
\`\`\`

#### Query Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| \`limit\` | number | 50 | Number of jobs to return (max 100) |
| \`offset\` | number | 0 | Number of jobs to skip |

#### Response

\`\`\`json
{
  "jobs": [
    {
      "id": "job_abc123",
      "url": "https://example.com",
      "status": "completed",
      "created_at": "2024-01-15T10:30:00Z",
      "completed_at": "2024-01-15T10:30:05Z"
    }
  ],
  "pagination": {
    "limit": 50,
    "offset": 0,
    "total": 1
  }
}
\`\`\`

## Status Codes

| Code | Description |
|------|-------------|
| 200 | Success |
| 400 | Bad Request - Invalid parameters |
| 401 | Unauthorized - Invalid API key |
| 404 | Not Found - Job not found |
| 429 | Too Many Requests - Rate limit exceeded |
| 500 | Internal Server Error |

## Rate Limits

- **Free Plan**: 100 requests per hour
- **Pro Plan**: 1,000 requests per hour
- **Enterprise**: Custom limits

Rate limit headers are included in all responses:

\`\`\`
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1642248000
\`\`\`

## Error Handling

All errors return a JSON response with an error message:

\`\`\`json
{
  "error": "Invalid URL format",
  "code": "INVALID_URL",
  "details": "The provided URL is not valid"
}
\`\`\`
`

  return <DocsContent content={content} />
}
