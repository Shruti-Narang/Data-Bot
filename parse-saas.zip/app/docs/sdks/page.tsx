import { DocsContent } from "@/components/docs/docs-content"

export default function SdksPage() {
  const content = `
# SDKs and Libraries

Parse Forge provides official SDKs and community libraries for popular programming languages.

## Official SDKs

### JavaScript/Node.js

Install via npm:

\`\`\`bash
npm install @parseforge/sdk
\`\`\`

#### Basic Usage

\`\`\`javascript
import { ParseForge } from '@parseforge/sdk';

const client = new ParseForge('your-api-key');

// Parse a website
const result = await client.parse({
  url: 'https://example.com',
  schema: {
    title: 'h1',
    content: '.content p'
  }
});

console.log(result.data);
\`\`\`

#### Advanced Usage

\`\`\`javascript
// With options
const result = await client.parse({
  url: 'https://example.com',
  schema: {
    products: '.product',
    prices: '.price'
  },
  options: {
    includeImages: true,
    includeLinks: true,
    maxDepth: 2
  }
});

// Get job status
const job = await client.getJob('job_123');

// List jobs
const jobs = await client.listJobs({ limit: 10 });
\`\`\`

### Python

Install via pip:

\`\`\`bash
pip install parseforge
\`\`\`

#### Basic Usage

\`\`\`python
from parseforge import ParseForge

client = ParseForge('your-api-key')

# Parse a website
result = client.parse(
    url='https://example.com',
    schema={
        'title': 'h1',
        'content': '.content p'
    }
)

print(result['data'])
\`\`\`

#### Advanced Usage

\`\`\`python
# With options
result = client.parse(
    url='https://example.com',
    schema={
        'products': '.product',
        'prices': '.price'
    },
    options={
        'include_images': True,
        'include_links': True,
        'max_depth': 2
    }
)

# Async support
import asyncio
from parseforge import AsyncParseForge

async def main():
    client = AsyncParseForge('your-api-key')
    result = await client.parse(url='https://example.com')
    print(result['data'])

asyncio.run(main())
\`\`\`

### PHP

Install via Composer:

\`\`\`bash
composer require parseforge/php-sdk
\`\`\`

#### Basic Usage

\`\`\`php
<?php
require_once 'vendor/autoload.php';

use ParseForge\\Client;

$client = new Client('your-api-key');

// Parse a website
$result = $client->parse([
    'url' => 'https://example.com',
    'schema' => [
        'title' => 'h1',
        'content' => '.content p'
    ]
]);

print_r($result['data']);
?>
\`\`\`

### Ruby

Install via gem:

\`\`\`bash
gem install parseforge
\`\`\`

#### Basic Usage

\`\`\`ruby
require 'parseforge'

client = ParseForge::Client.new('your-api-key')

# Parse a website
result = client.parse(
  url: 'https://example.com',
  schema: {
    title: 'h1',
    content: '.content p'
  }
)

puts result['data']
\`\`\`

## Community Libraries

### Go

\`\`\`bash
go get github.com/parseforge/go-sdk
\`\`\`

\`\`\`go
package main

import (
    "fmt"
    "github.com/parseforge/go-sdk"
)

func main() {
    client := parseforge.NewClient("your-api-key")
    
    result, err := client.Parse(parseforge.ParseRequest{
        URL: "https://example.com",
        Schema: map[string]string{
            "title": "h1",
            "content": ".content p",
        },
    })
    
    if err != nil {
        panic(err)
    }
    
    fmt.Println(result.Data)
}
\`\`\`

### Java

\`\`\`xml
<dependency>
    <groupId>com.parseforge</groupId>
    <artifactId>parseforge-java</artifactId>
    <version>1.0.0</version>
</dependency>
\`\`\`

\`\`\`java
import com.parseforge.ParseForgeClient;
import com.parseforge.models.ParseRequest;
import com.parseforge.models.ParseResponse;

public class Example {
    public static void main(String[] args) {
        ParseForgeClient client = new ParseForgeClient("your-api-key");
        
        ParseRequest request = ParseRequest.builder()
            .url("https://example.com")
            .schema(Map.of(
                "title", "h1",
                "content", ".content p"
            ))
            .build();
            
        ParseResponse response = client.parse(request);
        System.out.println(response.getData());
    }
}
\`\`\`

### C#

\`\`\`bash
dotnet add package ParseForge.NET
\`\`\`

\`\`\`csharp
using ParseForge;

var client = new ParseForgeClient("your-api-key");

var result = await client.ParseAsync(new ParseRequest
{
    Url = "https://example.com",
    Schema = new Dictionary<string, string>
    {
        ["title"] = "h1",
        ["content"] = ".content p"
    }
});

Console.WriteLine(result.Data);
\`\`\`

## Error Handling

All SDKs provide consistent error handling:

### JavaScript
\`\`\`javascript
try {
  const result = await client.parse({ url: 'invalid-url' });
} catch (error) {
  if (error.code === 'INVALID_URL') {
    console.log('Please provide a valid URL');
  } else if (error.code === 'RATE_LIMIT_EXCEEDED') {
    console.log('Rate limit exceeded, please wait');
  } else {
    console.log('Unexpected error:', error.message);
  }
}
\`\`\`

### Python
\`\`\`python
from parseforge.exceptions import ParseForgeError, RateLimitError

try:
    result = client.parse(url='invalid-url')
except RateLimitError:
    print('Rate limit exceeded, please wait')
except ParseForgeError as e:
    print(f'Error: {e.message}')
\`\`\`

## Configuration

### Timeouts
\`\`\`javascript
const client = new ParseForge('your-api-key', {
  timeout: 30000,  // 30 seconds
  retries: 3
});
\`\`\`

### Base URL (for self-hosted)
\`\`\`javascript
const client = new ParseForge('your-api-key', {
  baseUrl: 'https://your-parseforge-instance.com'
});
\`\`\`

### User Agent
\`\`\`javascript
const client = new ParseForge('your-api-key', {
  userAgent: 'MyApp/1.0'
});
\`\`\`

## Webhooks Integration

### JavaScript
\`\`\`javascript
// Express.js webhook handler
app.post('/webhook', express.raw({type: 'application/json'}), (req, res) => {
  const signature = req.headers['x-parseforge-signature'];
  const payload = req.body;
  
  if (client.verifyWebhook(payload, signature, 'your-webhook-secret')) {
    const event = JSON.parse(payload);
    
    if (event.type === 'job.completed') {
      console.log('Job completed:', event.data.job_id);
      // Process the completed job
    }
  }
  
  res.status(200).send('OK');
});
\`\`\`

### Python
\`\`\`python
from flask import Flask, request
import hmac
import hashlib

app = Flask(__name__)

@app.route('/webhook', methods=['POST'])
def webhook():
    signature = request.headers.get('X-ParseForge-Signature')
    payload = request.get_data()
    
    if verify_signature(payload, signature, 'your-webhook-secret'):
        event = request.get_json()
        
        if event['type'] == 'job.completed':
            print(f"Job completed: {event['data']['job_id']}")
            # Process the completed job
    
    return 'OK', 200

def verify_signature(payload, signature, secret):
    expected = hmac.new(
        secret.encode(),
        payload,
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(f'sha256={expected}', signature)
\`\`\`

## Contributing

We welcome contributions to our SDKs! Check out our repositories:

- [JavaScript SDK](https://github.com/parseforge/js-sdk)
- [Python SDK](https://github.com/parseforge/python-sdk)
- [PHP SDK](https://github.com/parseforge/php-sdk)
- [Ruby SDK](https://github.com/parseforge/ruby-sdk)

## Support

- [GitHub Issues](https://github.com/parseforge/sdks/issues)
- [Discord Community](https://discord.gg/parseforge)
- [Email Support](mailto:sdk-support@parseforge.com)
`

  return <DocsContent content={content} />
}
