import { DocsContent } from "@/components/docs/docs-content"

export default function SchemasPage() {
  const content = `
# Schema Guide

Schemas define exactly what data to extract from websites using CSS selectors. Without a schema, Parse Forge uses intelligent auto-detection.

## Basic Schema Structure

A schema is a JSON object where keys are field names and values are CSS selectors:

\`\`\`json
{
  "title": "h1",
  "description": ".description",
  "price": ".price"
}
\`\`\`

## CSS Selectors

Use standard CSS selectors to target elements:

### Element Selectors
\`\`\`json
{
  "heading": "h1",           // First h1 element
  "paragraph": "p",          // First p element
  "link": "a"                // First a element
}
\`\`\`

### Class Selectors
\`\`\`json
{
  "title": ".post-title",    // Element with class "post-title"
  "content": ".content",     // Element with class "content"
  "sidebar": ".sidebar"      // Element with class "sidebar"
}
\`\`\`

### ID Selectors
\`\`\`json
{
  "header": "#header",       // Element with id "header"
  "main": "#main-content"    // Element with id "main-content"
}
\`\`\`

### Attribute Selectors
\`\`\`json
{
  "email": "a[href^='mailto:']",     // Links starting with mailto:
  "external": "a[target='_blank']",   // Links with target="_blank"
  "image": "img[alt]"                 // Images with alt attribute
}
\`\`\`

## Multiple Elements

When a selector matches multiple elements, Parse Forge returns an array:

\`\`\`json
{
  "articles": ".article",           // Array of all .article elements
  "links": "a[href]",              // Array of all links
  "images": "img[src]"             // Array of all images
}
\`\`\`

## Nested Schemas

Create complex nested structures:

\`\`\`json
{
  "product": {
    "name": ".product-name",
    "price": ".price",
    "details": {
      "description": ".description",
      "specifications": ".specs li"
    }
  }
}
\`\`\`

## Common Patterns

### Blog Posts
\`\`\`json
{
  "title": "h1, .post-title",
  "author": ".author, .byline",
  "publishDate": ".date, .published, time",
  "content": ".content p, .post-content p",
  "tags": ".tag, .category",
  "comments": ".comment"
}
\`\`\`

### E-commerce Products
\`\`\`json
{
  "name": "h1, .product-title",
  "price": ".price, .cost",
  "originalPrice": ".original-price, .was-price",
  "description": ".description, .product-description",
  "images": ".product-image img",
  "rating": ".rating, .stars",
  "reviews": ".review",
  "availability": ".stock, .availability"
}
\`\`\`

### News Articles
\`\`\`json
{
  "headline": "h1, .headline",
  "subheading": "h2, .subheading",
  "author": ".author, .byline",
  "publishTime": "time, .publish-date",
  "body": ".article-body p",
  "tags": ".tag, .topic",
  "relatedArticles": ".related-article a"
}
\`\`\`

### Contact Information
\`\`\`json
{
  "companyName": "h1, .company-name",
  "address": ".address, .location",
  "phone": ".phone, .tel",
  "email": ".email, a[href^='mailto:']",
  "hours": ".hours, .business-hours",
  "socialMedia": ".social a[href]"
}
\`\`\`

## Advanced Selectors

### Pseudo-selectors
\`\`\`json
{
  "firstParagraph": "p:first-child",
  "lastItem": "li:last-child",
  "evenRows": "tr:nth-child(even)"
}
\`\`\`

### Combinators
\`\`\`json
{
  "directChild": ".parent > .child",
  "descendant": ".ancestor .descendant",
  "sibling": ".element + .sibling",
  "generalSibling": ".element ~ .sibling"
}
\`\`\`

### Multiple Selectors
Use commas to try multiple selectors (first match wins):

\`\`\`json
{
  "title": "h1, .title, .heading, .post-title",
  "price": ".price, .cost, .amount, .value"
}
\`\`\`

## Schema Validation

Parse Forge validates schemas before processing:

- ✅ Valid CSS selectors
- ✅ Reasonable nesting depth (max 5 levels)
- ✅ Appropriate field names
- ❌ Invalid selectors will return an error

## Testing Schemas

Use the [Playground](/dashboard/playground) to test your schemas:

1. Enter a URL
2. Create or paste your schema
3. Click "Parse" to see results
4. Refine selectors as needed

## Best Practices

1. **Start simple**: Begin with basic selectors and add complexity
2. **Use fallbacks**: Provide multiple selectors for important fields
3. **Be specific**: Target the exact elements you need
4. **Test thoroughly**: Verify schemas work across different pages
5. **Handle variations**: Account for different page layouts

## Auto-detection vs Schemas

| Auto-detection | Custom Schema |
|----------------|---------------|
| ✅ No setup required | ✅ Precise control |
| ✅ Works on any site | ✅ Consistent structure |
| ✅ Handles changes well | ✅ Better performance |
| ❌ Less precise | ❌ Requires maintenance |
| ❌ Generic field names | ❌ Site-specific |

Choose auto-detection for quick tests and exploration. Use schemas for production applications requiring consistent, structured data.
`

  return <DocsContent content={content} />
}
