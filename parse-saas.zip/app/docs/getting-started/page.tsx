import { DocsContent } from "@/components/docs/docs-content"

export default function GettingStartedPage() {
  const content = `
# Getting Started with Parse Forge

Parse Forge is a powerful web scraping API that transforms any website into structured JSON data. Get started in minutes with our simple REST API.

## Quick Start

### 1. Create an Account

Sign up for a free Parse Forge account at [parseforge.com](https://parseforge.com) to get your API key.

### 2. Get Your API Key

1. Log into your dashboard
2. Navigate to **API Keys**
3. Click **Create Key**
4. Copy your new API key

### 3. Make Your First Request

\`\`\`bash
curl -X POST https://api.parseforge.com/parse \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "url": "https://news.ycombinator.com",
    "schema": {
      "title": "h1",
      "stories": ".storylink"
    }
  }'
\`\`\`

### 4. Get Structured Data

Parse Forge will return clean, structured JSON:

\`\`\`json
{
  "success": true,
  "job_id": "job_123",
  "data": {
    "url": "https://news.ycombinator.com",
    "title": "Hacker News",
    "content": {
      "title": "Hacker News",
      "stories": [
        "Show HN: My new project",
        "Ask HN: How do you handle...",
        "..."
      ]
    },
    "metadata": {
      "timestamp": "2024-01-15T10:30:00Z",
      "wordCount": 1250,
      "imageCount": 5,
      "linkCount": 42
    }
  }
}
\`\`\`

## Key Features

- **Auto-detection**: Intelligent content extraction without schemas
- **Custom schemas**: Define exactly what data to extract
- **Multiple formats**: Export as JSON, CSV, Excel, or XML
- **Real-time webhooks**: Get notified when jobs complete
- **Rate limiting**: Built-in respect for robots.txt and rate limits
- **Integrations**: Connect with Zapier, Google Sheets, and more

## Next Steps

- [API Reference](/docs/api-reference) - Complete API documentation
- [Schema Guide](/docs/schemas) - Learn to create custom extraction schemas
- [Webhooks](/docs/webhooks) - Set up real-time notifications
- [SDKs](/docs/sdks) - Use our official SDKs and libraries

## Need Help?

- Check our [FAQ](/docs/faq) for common questions
- Join our [Discord community](https://discord.gg/parseforge)
- Email us at [support@parseforge.com](mailto:support@parseforge.com)
`

  return <DocsContent content={content} />
}
