import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"
import { parseWebsite } from "@/lib/parsing/parser"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    // Check authentication
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { url, schema, options = {} } = body

    if (!url) {
      return NextResponse.json({ error: "URL is required" }, { status: 400 })
    }

    // Validate URL format
    try {
      new URL(url)
    } catch {
      return NextResponse.json({ error: "Invalid URL format" }, { status: 400 })
    }

    // Create parse job in database
    const { data: job, error: jobError } = await supabase
      .from("parse_jobs")
      .insert({
        user_id: user.id,
        url,
        status: "processing",
      })
      .select()
      .single()

    if (jobError) {
      console.error("Failed to create parse job:", jobError)
      return NextResponse.json({ error: "Failed to create parse job" }, { status: 500 })
    }

    try {
      // Parse the website
      const result = await parseWebsite(url, schema, options)

      // Update job with results
      await supabase
        .from("parse_jobs")
        .update({
          status: "completed",
          result,
          completed_at: new Date().toISOString(),
        })
        .eq("id", job.id)

      return NextResponse.json({
        success: true,
        job_id: job.id,
        data: result,
      })
    } catch (parseError) {
      // Update job with error
      await supabase
        .from("parse_jobs")
        .update({
          status: "failed",
          error_message: parseError instanceof Error ? parseError.message : "Unknown parsing error",
          completed_at: new Date().toISOString(),
        })
        .eq("id", job.id)

      return NextResponse.json(
        {
          error: "Failed to parse website",
          details: parseError instanceof Error ? parseError.message : "Unknown error",
        },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("Parse API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
