import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest, { params }: { params: { jobId: string } }) {
  try {
    const supabase = await createClient()

    // Check authentication
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { jobId } = params

    // Get job details
    const { data: job, error: jobError } = await supabase
      .from("parse_jobs")
      .select("*")
      .eq("id", jobId)
      .eq("user_id", user.id)
      .single()

    if (jobError || !job) {
      return NextResponse.json({ error: "Job not found" }, { status: 404 })
    }

    return NextResponse.json({
      id: job.id,
      url: job.url,
      status: job.status,
      result: job.result,
      error_message: job.error_message,
      created_at: job.created_at,
      completed_at: job.completed_at,
    })
  } catch (error) {
    console.error("Get job API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
