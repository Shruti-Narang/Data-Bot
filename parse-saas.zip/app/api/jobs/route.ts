import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()

    // Check authentication
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const limit = Math.min(Number.parseInt(searchParams.get("limit") || "50"), 100)
    const offset = Number.parseInt(searchParams.get("offset") || "0")

    // Get user's parse jobs
    const { data: jobs, error: jobsError } = await supabase
      .from("parse_jobs")
      .select("id, url, status, created_at, completed_at, error_message")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1)

    if (jobsError) {
      console.error("Failed to fetch jobs:", jobsError)
      return NextResponse.json({ error: "Failed to fetch jobs" }, { status: 500 })
    }

    return NextResponse.json({
      jobs: jobs || [],
      pagination: {
        limit,
        offset,
        total: jobs?.length || 0,
      },
    })
  } catch (error) {
    console.error("Jobs API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
