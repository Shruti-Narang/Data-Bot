import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"
import * as XLSX from "xlsx"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { jobId, format } = body

    if (!jobId || !format) {
      return NextResponse.json({ error: "Missing jobId or format" }, { status: 400 })
    }

    // Get job data
    const { data: job, error: jobError } = await supabase
      .from("parse_jobs")
      .select("*")
      .eq("id", jobId)
      .eq("user_id", user.id)
      .single()

    if (jobError || !job) {
      return NextResponse.json({ error: "Job not found" }, { status: 404 })
    }

    if (job.status !== "completed" || !job.result) {
      return NextResponse.json({ error: "Job not completed or no results available" }, { status: 400 })
    }

    const data = job.result

    switch (format.toLowerCase()) {
      case "json":
        return new NextResponse(JSON.stringify(data, null, 2), {
          headers: {
            "Content-Type": "application/json",
            "Content-Disposition": `attachment; filename="parse-results-${jobId}.json"`,
          },
        })

      case "csv":
        const csv = convertToCSV(data.content)
        return new NextResponse(csv, {
          headers: {
            "Content-Type": "text/csv",
            "Content-Disposition": `attachment; filename="parse-results-${jobId}.csv"`,
          },
        })

      case "xlsx":
        const workbook = convertToExcel(data)
        const buffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" })
        return new NextResponse(buffer, {
          headers: {
            "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "Content-Disposition": `attachment; filename="parse-results-${jobId}.xlsx"`,
          },
        })

      case "xml":
        const xml = convertToXML(data)
        return new NextResponse(xml, {
          headers: {
            "Content-Type": "application/xml",
            "Content-Disposition": `attachment; filename="parse-results-${jobId}.xml"`,
          },
        })

      default:
        return NextResponse.json({ error: "Unsupported format" }, { status: 400 })
    }
  } catch (error) {
    console.error("Export API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

function convertToCSV(data: any): string {
  if (!data || typeof data !== "object") return ""

  const rows: string[] = []
  const headers = new Set<string>()

  // Collect all possible headers
  const collectHeaders = (obj: any, prefix = "") => {
    for (const [key, value] of Object.entries(obj)) {
      const fullKey = prefix ? `${prefix}.${key}` : key
      if (Array.isArray(value)) {
        headers.add(fullKey)
      } else if (typeof value === "object" && value !== null) {
        collectHeaders(value, fullKey)
      } else {
        headers.add(fullKey)
      }
    }
  }

  collectHeaders(data)
  const headerArray = Array.from(headers)
  rows.push(headerArray.join(","))

  // Add data row
  const getValue = (obj: any, path: string): string => {
    const keys = path.split(".")
    let current = obj
    for (const key of keys) {
      if (current && typeof current === "object" && key in current) {
        current = current[key]
      } else {
        return ""
      }
    }
    if (Array.isArray(current)) {
      return current.join("; ")
    }
    return String(current || "")
  }

  const row = headerArray.map((header) => `"${getValue(data, header).replace(/"/g, '""')}"`).join(",")
  rows.push(row)

  return rows.join("\n")
}

function convertToExcel(data: any): XLSX.WorkBook {
  const workbook = XLSX.utils.book_new()

  // Metadata sheet
  const metadataSheet = XLSX.utils.json_to_sheet([
    { Property: "URL", Value: data.url },
    { Property: "Title", Value: data.title },
    { Property: "Description", Value: data.description || "" },
    { Property: "Word Count", Value: data.metadata?.wordCount || 0 },
    { Property: "Image Count", Value: data.metadata?.imageCount || 0 },
    { Property: "Link Count", Value: data.metadata?.linkCount || 0 },
    { Property: "Parsed At", Value: data.metadata?.timestamp || "" },
  ])
  XLSX.utils.book_append_sheet(workbook, metadataSheet, "Metadata")

  // Content sheet
  if (data.content) {
    const flattenedData = flattenObject(data.content)
    const contentSheet = XLSX.utils.json_to_sheet([flattenedData])
    XLSX.utils.book_append_sheet(workbook, contentSheet, "Content")
  }

  return workbook
}

function convertToXML(data: any): string {
  const xmlHeader = '<?xml version="1.0" encoding="UTF-8"?>\n'

  const objectToXML = (obj: any, rootName = "root"): string => {
    let xml = `<${rootName}>\n`

    for (const [key, value] of Object.entries(obj)) {
      const sanitizedKey = key.replace(/[^a-zA-Z0-9_]/g, "_")

      if (Array.isArray(value)) {
        xml += `  <${sanitizedKey}>\n`
        value.forEach((item, index) => {
          if (typeof item === "object") {
            xml += `    <item_${index}>\n`
            xml += objectToXML(item, "").replace(/^/gm, "      ")
            xml += `    </item_${index}>\n`
          } else {
            xml += `    <item_${index}>${escapeXML(String(item))}</item_${index}>\n`
          }
        })
        xml += `  </${sanitizedKey}>\n`
      } else if (typeof value === "object" && value !== null) {
        xml += `  <${sanitizedKey}>\n`
        xml += objectToXML(value, "").replace(/^/gm, "    ")
        xml += `  </${sanitizedKey}>\n`
      } else {
        xml += `  <${sanitizedKey}>${escapeXML(String(value || ""))}</${sanitizedKey}>\n`
      }
    }

    xml += `</${rootName}>\n`
    return xml
  }

  return xmlHeader + objectToXML(data, "parseResults")
}

function escapeXML(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;")
}

function flattenObject(obj: any, prefix = ""): any {
  const flattened: any = {}

  for (const [key, value] of Object.entries(obj)) {
    const newKey = prefix ? `${prefix}.${key}` : key

    if (Array.isArray(value)) {
      flattened[newKey] = value.join("; ")
    } else if (typeof value === "object" && value !== null) {
      Object.assign(flattened, flattenObject(value, newKey))
    } else {
      flattened[newKey] = value
    }
  }

  return flattened
}
