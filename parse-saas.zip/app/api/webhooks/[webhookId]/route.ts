import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function PUT(request: NextRequest, { params }: { params: { webhookId: string } }) {
  try {
    const supabase = await createClient()

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { webhookId } = params
    const body = await request.json()
    const { name, url, events, secret, is_active } = body

    const { data: webhook, error } = await supabase
      .from("webhooks")
      .update({
        name,
        url,
        events,
        secret,
        is_active,
      })
      .eq("id", webhookId)
      .eq("user_id", user.id)
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: "Failed to update webhook" }, { status: 500 })
    }

    return NextResponse.json({ webhook })
  } catch (error) {
    console.error("Update webhook error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { webhookId: string } }) {
  try {
    const supabase = await createClient()

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { webhookId } = params

    const { error } = await supabase.from("webhooks").delete().eq("id", webhookId).eq("user_id", user.id)

    if (error) {
      return NextResponse.json({ error: "Failed to delete webhook" }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Delete webhook error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
