import * as cheerio from "cheerio"

export interface InferredSchema {
  type: string
  confidence: number
  schema: Record<string, string>
  suggestions: string[]
}

export function inferSchema(html: string, url: string): InferredSchema {
  const $ = cheerio.load(html)

  // Detect common page types
  const pageType = detectPageType($, url)

  let schema: Record<string, string> = {}
  let suggestions: string[] = []
  let confidence = 0.5

  switch (pageType.type) {
    case "product":
      schema = inferProductSchema($)
      suggestions = ["Consider extracting price, availability, and reviews"]
      confidence = pageType.confidence
      break

    case "article":
      schema = inferArticleSchema($)
      suggestions = ["Consider extracting author, publish date, and tags"]
      confidence = pageType.confidence
      break

    case "listing":
      schema = inferListingSchema($)
      suggestions = ["Consider extracting individual items and pagination"]
      confidence = pageType.confidence
      break

    case "contact":
      schema = inferContactSchema($)
      suggestions = ["Consider extracting address, phone, and business hours"]
      confidence = pageType.confidence
      break

    default:
      schema = inferGenericSchema($)
      suggestions = ["Generic content extraction - consider providing a custom schema"]
      confidence = 0.3
  }

  return {
    type: pageType.type,
    confidence,
    schema,
    suggestions,
  }
}

function detectPageType($: cheerio.CheerioAPI, url: string): { type: string; confidence: number } {
  const title = $("title").text().toLowerCase()
  const bodyText = $("body").text().toLowerCase()
  const urlPath = url.toLowerCase()

  // Product page indicators
  if (
    $(".price, .cost, .buy-now, .add-to-cart, .product-price").length > 0 ||
    title.includes("buy") ||
    title.includes("price") ||
    title.includes("shop") ||
    urlPath.includes("/product/") ||
    urlPath.includes("/item/")
  ) {
    return { type: "product", confidence: 0.8 }
  }

  // Article/blog indicators
  if (
    $("article, .article, .post, .blog-post").length > 0 ||
    $(".author, .byline, .publish-date, .article-date").length > 0 ||
    title.includes("blog") ||
    urlPath.includes("/blog/") ||
    urlPath.includes("/article/")
  ) {
    return { type: "article", confidence: 0.8 }
  }

  // Listing page indicators
  if (
    $(".listing, .search-results, .product-list, .item-list").length > 0 ||
    $(".pagination, .page-numbers").length > 0 ||
    $('[class*="grid"], [class*="list"]').length > 3
  ) {
    return { type: "listing", confidence: 0.7 }
  }

  // Contact page indicators
  if (
    $(".contact, .address, .phone, .email").length > 0 ||
    title.includes("contact") ||
    urlPath.includes("/contact") ||
    bodyText.includes("phone") ||
    bodyText.includes("address")
  ) {
    return { type: "contact", confidence: 0.7 }
  }

  return { type: "generic", confidence: 0.3 }
}

function inferProductSchema($: cheerio.CheerioAPI): Record<string, string> {
  return {
    name: 'h1, .product-title, .product-name, [class*="title"]',
    price: '.price, .cost, .product-price, [class*="price"]',
    description: ".description, .product-description, .summary",
    availability: ".availability, .stock, .in-stock, .out-of-stock",
    rating: ".rating, .stars, .review-score",
    reviews: ".reviews, .review-count",
    images: 'img[class*="product"], .product-image img',
    brand: '.brand, .manufacturer, [class*="brand"]',
  }
}

function inferArticleSchema($: cheerio.CheerioAPI): Record<string, string> {
  return {
    title: "h1, .article-title, .post-title",
    author: '.author, .byline, .writer, [class*="author"]',
    publishDate: ".date, .publish-date, .article-date, time",
    content: ".content, .article-content, .post-content, article p",
    tags: ".tags, .categories, .tag, .category",
    excerpt: ".excerpt, .summary, .description",
  }
}

function inferListingSchema($: cheerio.CheerioAPI): Record<string, string> {
  return {
    items: ".item, .listing, .product, .result",
    titles: ".item h2, .item h3, .listing h2, .listing h3",
    prices: ".item .price, .listing .price",
    links: ".item a, .listing a",
    images: ".item img, .listing img",
  }
}

function inferContactSchema($: cheerio.CheerioAPI): Record<string, string> {
  return {
    name: "h1, .company-name, .business-name",
    address: '.address, .location, [class*="address"]',
    phone: '.phone, .tel, [class*="phone"]',
    email: '.email, [class*="email"]',
    hours: '.hours, .business-hours, [class*="hours"]',
    description: ".about, .description, .summary",
  }
}

function inferGenericSchema($: cheerio.CheerioAPI): Record<string, string> {
  return {
    title: "h1",
    headings: "h2, h3",
    content: "p",
    links: "a[href]",
    images: "img[src]",
  }
}
