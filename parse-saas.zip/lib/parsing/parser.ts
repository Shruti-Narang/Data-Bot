import * as cheerio from "cheerio"

export interface ParseOptions {
  includeImages?: boolean
  includeLinks?: boolean
  maxDepth?: number
  followPagination?: boolean
  customSelectors?: Record<string, string>
}

export interface ParsedData {
  url: string
  title: string
  description?: string
  content: any
  metadata: {
    timestamp: string
    contentType: string
    wordCount: number
    imageCount: number
    linkCount: number
  }
  schema?: any
}

export async function parseWebsite(url: string, schema?: any, options: ParseOptions = {}): Promise<ParsedData> {
  try {
    // Fetch the webpage
    const response = await fetch(url, {
      headers: {
        "User-Agent": "Parse Forge Bot/1.0 (+https://parseforge.com/bot)",
      },
    })

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`)
    }

    const html = await response.text()
    const $ = cheerio.load(html)

    // Extract basic metadata
    const title = $("title").text().trim() || $("h1").first().text().trim() || "Untitled"
    const description =
      $('meta[name="description"]').attr("content") || $('meta[property="og:description"]').attr("content") || ""

    // Remove script and style elements
    $("script, style, nav, footer, .advertisement, .ads").remove()

    let content: any = {}

    if (schema) {
      // Use provided schema to extract structured data
      content = extractWithSchema($, schema)
    } else {
      // Auto-detect and extract common patterns
      content = autoExtractContent($, options)
    }

    // Calculate metadata
    const textContent = $.text()
    const wordCount = textContent.split(/\s+/).filter((word) => word.length > 0).length
    const imageCount = $("img").length
    const linkCount = $("a[href]").length

    return {
      url,
      title,
      description,
      content,
      metadata: {
        timestamp: new Date().toISOString(),
        contentType: response.headers.get("content-type") || "text/html",
        wordCount,
        imageCount,
        linkCount,
      },
      schema,
    }
  } catch (error) {
    throw new Error(`Failed to parse website: ${error instanceof Error ? error.message : "Unknown error"}`)
  }
}

function extractWithSchema($: cheerio.CheerioAPI, schema: any): any {
  const result: any = {}

  for (const [key, selector] of Object.entries(schema)) {
    if (typeof selector === "string") {
      const elements = $(selector as string)
      if (elements.length === 1) {
        result[key] = elements.text().trim()
      } else if (elements.length > 1) {
        result[key] = elements.map((_, el) => $(el).text().trim()).get()
      } else {
        result[key] = null
      }
    } else if (typeof selector === "object" && selector !== null) {
      // Nested schema
      result[key] = extractWithSchema($, selector)
    }
  }

  return result
}

function autoExtractContent($: cheerio.CheerioAPI, options: ParseOptions): any {
  const content: any = {}

  // Extract headings
  const headings: any[] = []
  $("h1, h2, h3, h4, h5, h6").each((_, el) => {
    const $el = $(el)
    headings.push({
      level: Number.parseInt(el.tagName.substring(1)),
      text: $el.text().trim(),
    })
  })
  if (headings.length > 0) content.headings = headings

  // Extract paragraphs
  const paragraphs = $("p")
    .map((_, el) => $(el).text().trim())
    .get()
    .filter((p) => p.length > 0)
  if (paragraphs.length > 0) content.paragraphs = paragraphs

  // Extract lists
  const lists: any[] = []
  $("ul, ol").each((_, el) => {
    const $el = $(el)
    const items = $el
      .find("li")
      .map((_, li) => $(li).text().trim())
      .get()
    if (items.length > 0) {
      lists.push({
        type: el.tagName.toLowerCase(),
        items,
      })
    }
  })
  if (lists.length > 0) content.lists = lists

  // Extract tables
  const tables: any[] = []
  $("table").each((_, el) => {
    const $table = $(el)
    const headers = $table
      .find("th")
      .map((_, th) => $(th).text().trim())
      .get()
    const rows: any[] = []

    $table.find("tr").each((_, tr) => {
      const $tr = $(tr)
      const cells = $tr
        .find("td")
        .map((_, td) => $(td).text().trim())
        .get()
      if (cells.length > 0) {
        if (headers.length > 0) {
          const rowObj: any = {}
          cells.forEach((cell, index) => {
            rowObj[headers[index] || `column_${index}`] = cell
          })
          rows.push(rowObj)
        } else {
          rows.push(cells)
        }
      }
    })

    if (rows.length > 0) {
      tables.push({ headers, rows })
    }
  })
  if (tables.length > 0) content.tables = tables

  // Extract images if requested
  if (options.includeImages) {
    const images = $("img")
      .map((_, el) => {
        const $el = $(el)
        return {
          src: $el.attr("src"),
          alt: $el.attr("alt") || "",
          title: $el.attr("title") || "",
        }
      })
      .get()
      .filter((img) => img.src)
    if (images.length > 0) content.images = images
  }

  // Extract links if requested
  if (options.includeLinks) {
    const links = $("a[href]")
      .map((_, el) => {
        const $el = $(el)
        return {
          href: $el.attr("href"),
          text: $el.text().trim(),
          title: $el.attr("title") || "",
        }
      })
      .get()
      .filter((link) => link.href && link.text)
    if (links.length > 0) content.links = links
  }

  // Extract custom selectors if provided
  if (options.customSelectors) {
    for (const [key, selector] of Object.entries(options.customSelectors)) {
      const elements = $(selector)
      if (elements.length === 1) {
        content[key] = elements.text().trim()
      } else if (elements.length > 1) {
        content[key] = elements.map((_, el) => $(el).text().trim()).get()
      }
    }
  }

  return content
}
