-- Create parse jobs table to track parsing requests
CREATE TABLE IF NOT EXISTS public.parse_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  result JSONB,
  error_message TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  completed_at TIMESTAMP WITH TIME ZONE
);

-- Enable RLS
ALTER TABLE public.parse_jobs ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "parse_jobs_select_own" ON public.parse_jobs 
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "parse_jobs_insert_own" ON public.parse_jobs 
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "parse_jobs_update_own" ON public.parse_jobs 
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "parse_jobs_delete_own" ON public.parse_jobs 
  FOR DELETE USING (auth.uid() = user_id);
