-- Create webhooks table for real-time notifications
CREATE TABLE IF NOT EXISTS public.webhooks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  url TEXT NOT NULL,
  events TEXT[] NOT NULL DEFAULT '{}',
  secret TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  last_triggered_at TIMESTAMP WITH TIME ZONE,
  failure_count INTEGER DEFAULT 0
);

-- Enable RLS
ALTER TABLE public.webhooks ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "webhooks_select_own" ON public.webhooks 
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "webhooks_insert_own" ON public.webhooks 
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "webhooks_update_own" ON public.webhooks 
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "webhooks_delete_own" ON public.webhooks 
  FOR DELETE USING (auth.uid() = user_id);
