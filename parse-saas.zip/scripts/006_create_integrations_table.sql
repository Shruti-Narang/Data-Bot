-- Create integrations table for external service connections
CREATE TABLE IF NOT EXISTS public.integrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('zapier', 'google_sheets', 'slack', 'discord', 'email')),
  config JSONB NOT NULL DEFAULT '{}',
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  last_used_at TIMESTAMP WITH TIME ZONE
);

-- Enable RLS
ALTER TABLE public.integrations ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "integrations_select_own" ON public.integrations 
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "integrations_insert_own" ON public.integrations 
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "integrations_update_own" ON public.integrations 
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "integrations_delete_own" ON public.integrations 
  FOR DELETE USING (auth.uid() = user_id);
